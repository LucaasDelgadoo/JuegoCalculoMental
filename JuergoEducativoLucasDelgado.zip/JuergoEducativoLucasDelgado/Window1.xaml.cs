﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace JuergoEducativoLucasDelgado
{
    public partial class Window1 : Window
    {
        private int respuestaCorrecta;
        private Random random = new Random();
        private List<Button> botones;
        private string nombreJugador;

        private int totalAciertos = 0;
        private int totalFallos = 0;
        private int puntuacion = 0;
        private int preguntaActual = 0;
        private int totalPreguntas = 10;
        private int nivel = 0;
        private string nivelDificultad = "medio";
        private int puntaje = 0;

        public Window1(string nombreUsuario)
        {
            InitializeComponent();
            MessageBox.Show("Selecciona un nivel para comenzar a jugar");
            Solucion1.Click += Respuesta_Click;
            Solucion2.Click += Respuesta_Click;
            Solucion3.Click += Respuesta_Click;
            Solucion4.Click += Respuesta_Click;
            Solucion5.Click += Respuesta_Click;


            botones = new List<Button> { Solucion1, Solucion2, Solucion3, Solucion4, Solucion5 };
            textoPuntuacion.Text = $"{puntuacion}";
            GenerarSiguientePregunta();

            selectorDificultad.Items.Add("Selecciona un nivel de dificultad");
            selectorDificultad.Items.Add("Fácil");
            selectorDificultad.Items.Add("Medio");
            selectorDificultad.Items.Add("Difícil");

            nombreJugador = nombreUsuario;
            txtNombreJugador.Text = nombreJugador;
        }

        private void Puntuacion(object sender, TextChangedEventArgs e) { }
        private void TextBox_TextChanged(object sender, TextChangedEventArgs e) { }

        public string GenerarOperacion()
        {
            int numero1 = random.Next(1, 21);
            int numero2 = random.Next(1, 21);
            bool esSuma = random.Next(0, 2) == 0;
            string operacion;
            if (esSuma)
            {
                operacion = $"{numero1} + {numero2}";
            }
            else
            {
                if (numero1 < numero2)
                {
                    int temp = numero1;
                    numero1 = numero2;
                    numero2 = temp;
                }
                operacion = $"{numero1} - {numero2}";
            }
            return operacion;
        }

        private void textoOperaciones_TextChanged(object sender, TextChangedEventArgs e)
        {
            string operacionesFacil = GenerarOperacion();
        }

        private void selectorDificultad_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string seleccionado = selectorDificultad.SelectedItem as string;

            if (seleccionado != null && seleccionado != "Selecciona un nivel de dificultad")
            {
                nivelDificultad = seleccionado.ToLower(); 
                MessageBox.Show($"Nivel seleccionado: {seleccionado}");

                preguntaActual = 0; 
                puntuacion = 0;
                textoPuntuacion.Text = $"{puntuacion}";

                GenerarSiguientePregunta(); 
            }
            else
            {
                MessageBox.Show("No seleccionaste nada");
                textoOperaciones.Text = ""; 
            }
        }


        private void GenerarPregunta()
        {
            int a = random.Next(1, 21);
            int b = random.Next(1, 21);
            respuestaCorrecta = a + b;
            textoOperaciones.Text = $"{a} + {b} = ?";

            var respuestas = new HashSet<int> { respuestaCorrecta };
            while (respuestas.Count < 5)
            {
                int fake = respuestaCorrecta + random.Next(-10, 11);
                if (fake != respuestaCorrecta && fake >= 0)
                    respuestas.Add(fake);
            }

            var listaRespuestas = respuestas.OrderBy(x => random.Next()).ToList();
            for (int i = 0; i < botones.Count; i++)
                botones[i].Content = listaRespuestas[i].ToString();
        }

        private void GenerarSiguientePregunta()
        {
            if (preguntaActual >= totalPreguntas)
            {
                MessageBox.Show($"Fin del juego! Puntaje final: {puntuacion}");
                return;
            }

            preguntaActual++;

            (string operacion, int resultado) = GenerarOperacion(nivelDificultad);
            respuestaCorrecta = resultado;
            textoOperaciones.Text = operacion;

            AsignarRespuestas();

            String textoNivel = nivel.ToString();
            textoNivel = $"Pregunta {preguntaActual} de {totalPreguntas} - Nivel: {nivelDificultad}";
        }


        private (string, int) GenerarOperacion(string nivel)
        {
            int a, b, resultado;
            string opTexto;
            int operador; // 0 = suma, 1 = resta, 2 = multiplicación

            switch (nivel.ToLower())
            {
                case "fácil":
                case "facil":
                    a = random.Next(1, 11);
                    b = random.Next(1, 11);
                    operador = random.Next(0, 2); // suma o resta

                    if (operador == 0)
                    {
                        resultado = a + b;
                        opTexto = $"{a} + {b} = ?";
                    }
                    else
                    {
                        if (a < b) (a, b) = (b, a); // evitar negativos
                        resultado = a - b;
                        opTexto = $"{a} - {b} = ?";
                    }
                    break;

                case "medio":
                    a = random.Next(10, 51);
                    b = random.Next(10, 51);
                    operador = random.Next(0, 2); // suma o resta

                    if (operador == 0)
                    {
                        resultado = a + b;
                        opTexto = $"{a} + {b} = ?";
                    }
                    else
                    {
                        if (a < b) (a, b) = (b, a);
                        resultado = a - b;
                        opTexto = $"{a} - {b} = ?";
                    }
                    break;

                case "difícil":
                case "dificil":
                    a = random.Next(50, 101);
                    b = random.Next(50, 101);
                    operador = random.Next(0, 3); // suma, resta o multiplicación

                    if (operador == 0)
                    {
                        resultado = a + b;
                        opTexto = $"{a} + {b} = ?";
                    }
                    else if (operador == 1)
                    {
                        if (a < b) (a, b) = (b, a);
                        resultado = a - b;
                        opTexto = $"{a} - {b} = ?";
                    }
                    else
                    {
                        resultado = a * b;
                        opTexto = $"{a} × {b} = ?";
                    }
                    break;

                default:
                    // Por si acaso no hay nivel definido
                    a = random.Next(1, 11);
                    b = random.Next(1, 11);
                    resultado = a + b;
                    opTexto = $"{a} + {b} = ?";
                    break;
            }

            return (opTexto, resultado);
        }


        private void AsignarRespuestas()
        {
            var respuestas = new HashSet<int> { respuestaCorrecta };

            while (respuestas.Count < 5)
            {

                int fake = respuestaCorrecta + random.Next(-10, 11);
                if (fake != respuestaCorrecta && fake >= 0)
                    respuestas.Add(fake);

            }

            var listaRespuestas = respuestas.OrderBy(x => random.Next()).ToList();

            for (int i = 0; i < botones.Count; i++)

                botones[i].Content = listaRespuestas[i].ToString();

            }


        private void Respuesta_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as Button;
            if (btn == null) return;

            int seleccion;

            if (!int.TryParse(btn.Content.ToString(), out seleccion)) return;

            if (seleccion == respuestaCorrecta)
            {

                puntuacion += 10;
                aciertos();
                MessageBox.Show("¡Correcto! +10 puntos");

            }
            else
            {

                puntuacion -= 5;
                fallos();
                MessageBox.Show($"Incorrecto. La respuesta correcta era {respuestaCorrecta}. -5 puntos");

            }

            textoPuntuacion.Text = $"{puntuacion}";

            GenerarSiguientePregunta();
        }




        private void TextBox_TextChanged_2(object sender, TextChangedEventArgs e)
        {

        }

        private void aciertos()
        {
            totalAciertos++;
            AciertosTexto.Text = totalAciertos.ToString(); // Asignar el valor actualizado
        }

        private void fallos()
        {
            totalFallos++;
            FallosTexto.Text = totalFallos.ToString(); // Asignar el valor actualizado
        }

        private void Solucion5_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Solucion4_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Solucion3_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Solucion2_Click(object sender, RoutedEventArgs e)
        {

        }

        private void Solucion1_Click(object sender, RoutedEventArgs e)
        {

        }

        private void AciertosTexto_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void FallosTexto_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void VolverMenu_Click(object sender, RoutedEventArgs e)
        {
            MainWindow menu = new MainWindow();
            menu.Show();
            this.Close();
        }

    }
}
