﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace JuergoEducativoLucasDelgado
{ 
    public partial class MainWindow : Window
    {


        public MainWindow()
        {
            InitializeComponent();
        }

        private void Boton_Jugar(object sender, RoutedEventArgs e)
        {

            string nombreJugador = txtNombreUsuario.Text.Trim();

            if (string.IsNullOrEmpty(nombreJugador))
            {
                MessageBox.Show("Por favor, introduce tu nombre antes de jugar.", "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var ventanaJuego = new Window1(nombreJugador);
            ventanaJuego.Show();
        }

        private void Boton_Salir(object sender, RoutedEventArgs e)
        {
            MessageBoxResult resultado = MessageBox.Show(
                "¿Estás seguro de que deseas salir del juego?",
                "Confirmar salida",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (resultado == MessageBoxResult.Yes)
            {
                Application.Current.Shutdown();
            }
        }


        public void nombreUsuario(object sender, TextChangedEventArgs e)
        {

        }
    }

}